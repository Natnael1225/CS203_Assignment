package midtermProject_CS203_2;

public interface GamingVideos {
	
	public String getGameName();

}
