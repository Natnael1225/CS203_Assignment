package midtermProject_CS203_2;

public interface CookingVideos {
	
	public String[] getIngredientsList();
	
	public Recipe getCookingRecipe();
	
	public String printRecipe();

}
