package assignment_5;

public interface Shape {

	public double area();
}
