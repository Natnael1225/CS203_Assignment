package assignment_3;

public class Demo1 {

	public static void main(String[] args) {
		/**
		 * Question A
		 * To find the output
		 */
		
		int i[] = new int[10];
		System.out.println(i[8]);
/**
 * The output is 0 b/c we create the int array size only
 * not passing the value yet.
 */

	}
}
