package assignment_3;

public class Demo2 {

	public static void main(String[] args) {

		/**
		 * Question B
		 * To find the output
		 */
		Student students[] = new Student[10];
		
		System.out.println(students[5]);
		
		/**
		 * The output is null b/c we create the size
	 * student array class only, Not giving the value yet.
		 * 
		 */
	}

}
