package assignment_3;

public class Demo3 {

	public static void main(String[] args) {

		/**
		 * Question C
		 * To find the output
		 */
		
         Student students[] = new Student[10];
		
		       System.out.println(students[5].getName());	

	/**
	 * The output is Error NullPointerException b/c 
	 *  we create the size student array not assign values. so
	 *  in this we getting name from null Student class
	* 
	 */
	}

}
