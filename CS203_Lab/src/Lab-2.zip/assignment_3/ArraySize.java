package assignment_3;

public class ArraySize {

	public static void main(String[] args) {
		/**
		 * Question- 6
		 */
		
/**
 * We can't change the size of array once we create it.
 * We are not allowed to insert values and
 *  delete the element  once we create an array.. 
 */

	}

}
