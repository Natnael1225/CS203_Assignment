package polyasset;

public class Automobiles extends Assets {
	
	

	public Automobiles(int serialNumber, String category, int quantity) {
		super(serialNumber, category,quantity);
		
	}

			
}
