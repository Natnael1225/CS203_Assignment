package polyasset;

public class Furniture extends Assets {

	public Furniture(int serialNumber, String category, int quantity) {
		super(serialNumber, category, quantity);
		
	}

}
