package polyasset;

public class CompactDisks extends Assets {

	
	public CompactDisks(int serialNumber, String category,int quantity) {
		super(serialNumber, category,quantity);
	}

	@Override
	public String toString() {
		return  super.toString();
	}
	
	
}
