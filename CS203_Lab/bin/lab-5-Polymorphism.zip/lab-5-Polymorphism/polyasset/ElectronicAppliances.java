package polyasset;

public class ElectronicAppliances  extends Assets{

	
	
	public ElectronicAppliances(int serialNumber, String category, int quantity) {
		super(serialNumber, category, quantity);
	
	}

	@Override
	public String toString() {
		return  super.toString();
	}

	
}
